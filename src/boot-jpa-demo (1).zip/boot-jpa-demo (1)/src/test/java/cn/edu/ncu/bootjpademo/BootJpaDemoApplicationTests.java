package cn.edu.ncu.bootjpademo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootJpaDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
