package cn.edu.ncu.bootjpademo.service;

import org.junit.Test;
import org.junit.platform.commons.logging.Logger;
import org.junit.platform.commons.logging.LoggerFactory;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@SpringBootTest
public class BookCategoryServiceTest {
    private final Logger logger =
            LoggerFactory.getLogger(this.getClass());
    @Autowired
    private BookCategoryService service;
    @Test
    public void findAll() {
        //logger.debug(service.findAll().toString());
    }
}