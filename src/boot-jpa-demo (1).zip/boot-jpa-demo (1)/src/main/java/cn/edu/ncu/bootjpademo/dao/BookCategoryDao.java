package cn.edu.ncu.bootjpademo.dao;

import cn.edu.ncu.bootjpademo.entity.BookCategory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.awt.print.Book;
import java.math.BigInteger;
import java.util.List;


@Repository
public interface BookCategoryDao extends JpaRepository<BookCategory,BigInteger> {
    List<Book> findBookByCategoryId(@Param("id") String id);
}
