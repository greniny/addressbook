package cn.edu.ncu.bootjpademo.entity;

import javax.persistence.*;
import java.math.BigInteger;
import java.sql.Timestamp;


@Entity
public class BookCategory {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private BigInteger categoryId;

    private String categoryName;

    private Timestamp createTime;



}
